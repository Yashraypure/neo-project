# Internshala Ethical Hacking Final Project

Tested the e-commerce platform(povided during the training) and found all possible vulnerabilities and loopholes in it, collected the relevant PoCs and then prepared a
Detailed Developer Level Report. This project was a part of the Online Training on Ethical Hacking I did from [Internshala Trainings](https://trainings.internshala.com/).

<hr>

If I was of any help then consider [buying me a coffee](https://www.buymeacoffee.com/shubhadeep394) ☕😉
